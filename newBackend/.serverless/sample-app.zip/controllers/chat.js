const Chat = require("../models/chat");


// Creates an item
exports.createTodo = (req, res, next) => {
    const chat = new Chat({
        source: req.body.source,
        destination: req.body.destination,
        content: req.body.content,
    });

    chat
        .save()
        .then((result) => {
            res.status(201).json({
                message: "Todo added successfully",
                post: {
                    ...result,
                    id: result._id,
                },
            });
        })
        .catch((err) => {
            console.log(req.body)
            console.log(req.body.source)
            console.log(req.body.destination)
            console.log(req.body.content)
            res.status(500).json({
                message: 'Fail to create todo!',
                
            });
        });
};

// Gets all items
exports.getTodos = (req, res, next) => {
    const pageSize = +req.query.pagesize;
    const currPage = +req.query.page;
    const todoQuery = Chat.find();
    let fetchedTodo;
    if (pageSize && currPage) {
        todoQuery.skip(pageSize * (currPage - 1)).limit(pageSize);
    }
    todoQuery
        .then((doc) => {
            fetchedTodo = doc;
            return Chat.countDocuments();
        })
        .then((count) => {
            res.status(200).json({
                message: "All Todos fetched 200!",
                posts: fetchedTodo,
                maxPosts: count,
            });
        })
        .catch((error) => {
            res.status(500).json({
                message: "Fetching todos failed!",
            });
        });
};


// Gets an item
exports.getTodoById = (req, res, next) => {
    Chat.findById(req.params.id)
        .then((post) => {
            if (post) {
                res.status(200).json(post);
            } else {
                res.status(404).json({ message: "Todo not found!"});
            }
        })
        .catch((error) => {
            res.status(500).json({
                message: "Fetching todo failed!",
            });
        });
};



// Update an item
exports.updateTodo = (req, res, next) => {
    const todo = new Chat({
        _id: req.body.id,
        source: req.body.source,
        destination: req.body.destination,
        content: req.body.content,
    });

    Chat.updateOne({ _id: req.params.id }, todo)
        .then((result) => {
            res.status(200).json({ message: "Update is successful!"
        });
            })
            .catch((error) => {
                res.status(500).json({
                    message: "Couldnt update todo!", 
                });
            });
};


// Delete an item
exports.deleteTodo = (req, res, next) => {
    Chat.deleteOne({ _id: req.params.id })
        .then((respt) => {
            res.status(200).json({ message: "Delete is successful!"});
        })
        .catch((error) => {
            res.status(500).json({
                message: "Couldnt delete todo!",
            });
        });
};