const express = require("express");
const serverless = require('serverless-http');


const app = express();
const mongoose = require("mongoose");

const bodyParser = require("body-parser");

const chatRoutes = require("./routes/chats.js");


main()
    .then((res) => console.log(res))
    .catch((err) => console.log(err));

async function main() {
    await mongoose.connect("mongodb+srv://billybobjak:testPassword123@cluster0.vkmav9o.mongodb.net/?retryWrites=true&w=majority");
}

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false}));

// app.get("/", (req, res) => {
//     res.send("Hello World");
// });

app.use("", chatRoutes);

module.exports.handler = serverless(app);



//  app.listen(8080, () => {
//      console.log("listening on port 8080")
//  });