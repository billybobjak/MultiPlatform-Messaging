const mongoose = require("mongoose");

const chatSchema = mongoose.Schema({
    source: {type: String, required: true},
    destination: {type: String, required: true},
    content: {type: String, required: true},
    //date: {type: Date, default: Date.now},
});

module.exports = mongoose.model('Chat', chatSchema);

// const conversationSchema = mongoose.Schema({

//     participants: {type: Array, required: true},
//     messages: [chatSchema],
// });

// module.exports = mongoose.model('Conversation', conversationSchema);